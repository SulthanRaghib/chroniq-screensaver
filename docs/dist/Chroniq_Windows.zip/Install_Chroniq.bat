@echo off
title Install Chroniq Screensaver
echo ==================================================
echo   INSTALLING CHRONIQ SCREENSAVER KE WINDOWS
echo ==================================================
echo.
copy /y "%~dp0Chroniq.scr" "%SystemRoot%\System32\Chroniq.scr" >nul
rundll32.exe desk.cpl,InstallScreenSaver %SystemRoot%\System32\Chroniq.scr
echo [SUKSES] Chroniq Screensaver berhasil dipasang ke Windows!
pause
